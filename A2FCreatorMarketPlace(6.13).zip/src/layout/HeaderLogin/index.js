import HeaderBarScrollToHide from "./HeaderBarScrollToHide";
import HeaderContent from "./HeaderContent";

const Header = () => {
  return <HeaderBarScrollToHide />;
};
export default Header;
