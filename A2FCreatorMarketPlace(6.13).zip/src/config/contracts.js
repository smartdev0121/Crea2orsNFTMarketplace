export const marketplace_contract_address = {
  3: "0xA389493d7fDAF0Ef4187FFa410B3f6ff9DB7AC6E", //ropsten
  // 4: '0x3D9c17469F520aA88465928e8655a4111A72766e', //rinkeby
  // 4: '0xE149DA7Fd43C577B9b6d8C071C5986Adc9dCC9eb', //rinkeby
  // 4: '0xE3cD297BAE1A73aDeD2E43C0914404742b55Fc99', //fix issue on make offer
  4: "0x8Af42D63111125166C1C7e3c91b0f260A86f1870", //fix place bid issue
  97: "0x956CC6E76b825aedCcefefC1D25c96daD27Ff37B",
  80001: "0x435b204107ccdfB3516c5A2f552Ce713A87c466e",
  250: "0xE9020EA2aB23Bc8B15823F7Ec9Fb17Bd5bb6B150",
  32520: "0xFde70d1f065c62b35a0B234832C03D7C0CC24ce7",
};

export const currencyTokenAddress =
  "0xcaa395E63Eaf26bb65fF906ccC9F3752594b614B";
