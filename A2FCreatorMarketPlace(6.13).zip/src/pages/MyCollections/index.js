import MyCollections from "./MyCollections";

export default MyCollections;
