import AllCollections from "./AllCollections";

export default AllCollections;
