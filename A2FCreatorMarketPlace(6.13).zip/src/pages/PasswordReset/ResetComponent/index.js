import ResetComponent from "./ResetComponent";

export default ResetComponent;
