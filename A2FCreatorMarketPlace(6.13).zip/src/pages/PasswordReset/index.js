import PasswordReset from "./PasswordReset";

export default PasswordReset;
