import EmailConfirmed from "./EmailConfirmed";

export default EmailConfirmed;
