import MyNFTs from "./MyNFTs";

export default MyNFTs;
