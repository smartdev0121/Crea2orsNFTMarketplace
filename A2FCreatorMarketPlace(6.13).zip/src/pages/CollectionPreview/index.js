import CollectionView from "./CollectionView";

export default CollectionView;
